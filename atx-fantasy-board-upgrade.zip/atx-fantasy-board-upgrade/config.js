window.ATX_CONFIG = {
  brandName: 'ATX Fantasy',
  oddsApiUrl: '',
  oddsApiKey: '',
  enableLiveFetch: false,
  refreshSeconds: 30
};
