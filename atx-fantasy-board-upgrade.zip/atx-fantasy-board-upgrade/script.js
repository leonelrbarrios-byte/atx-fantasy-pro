const sampleBets = [
  { sport: 'NBA', player: 'Luka Doncic', prop: 'Over 8.5 Assists', type: 'Assists', book: 'DraftKings', bookOdds: '+120', fairOdds: '+101', hitRate: '70%', edge: 9.5 },
  { sport: 'NBA', player: 'Jayson Tatum', prop: 'Over 2.5 3PM', type: '3PM', book: 'FanDuel', bookOdds: '+125', fairOdds: '+108', hitRate: '66%', edge: 8.1 },
  { sport: 'NBA', player: 'Stephen Curry', prop: 'Over 29.5 Points', type: 'Points', book: 'BetMGM', bookOdds: '+110', fairOdds: '-102', hitRate: '63%', edge: 6.0 },
  { sport: 'NBA', player: 'Nikola Jokic', prop: 'Over 47.5 PRA', type: 'PRA', book: 'Caesars', bookOdds: '+118', fairOdds: '+102', hitRate: '65%', edge: 7.0 },
  { sport: 'NBA', player: 'Anthony Edwards', prop: 'Over 5.5 Assists', type: 'Assists', book: 'Fanatics', bookOdds: '+132', fairOdds: '+115', hitRate: '59%', edge: 6.8 },
  { sport: 'MLB', player: 'Juan Soto', prop: 'Over 1.5 Total Bases', type: 'Total Bases', book: 'BetMGM', bookOdds: '+140', fairOdds: '+122', hitRate: '61%', edge: 7.9 },
  { sport: 'MLB', player: 'Ronald Acuña Jr.', prop: 'To Score a Run', type: 'Runs', book: 'Caesars', bookOdds: '+115', fairOdds: '+103', hitRate: '64%', edge: 5.9 },
  { sport: 'MLB', player: 'Aaron Judge', prop: 'To Hit a Home Run', type: 'HR', book: 'ESPN BET', bookOdds: '+305', fairOdds: '+278', hitRate: '24%', edge: 5.1 },
  { sport: 'MLB', player: 'Mookie Betts', prop: 'Over 1.5 Hits+Runs+RBIs', type: 'H+R+RBI', book: 'Underdog', bookOdds: '-105', fairOdds: '-118', hitRate: '58%', edge: 4.6 },
  { sport: 'MLB', player: 'Bobby Witt Jr.', prop: 'Over 0.5 Stolen Bases', type: 'Stolen Bases', book: 'PrizePicks', bookOdds: '+210', fairOdds: '+186', hitRate: '33%', edge: 5.8 },
  { sport: 'CS2', player: 'ZywOo', prop: 'Over 20.5 Kills', type: 'Kills', book: 'Pinnacle', bookOdds: '+118', fairOdds: '+104', hitRate: '68%', edge: 6.9 },
  { sport: 'CS2', player: 'NiKo', prop: 'Over 19.5 Kills', type: 'Kills', book: 'Bet365', bookOdds: '+112', fairOdds: '+101', hitRate: '65%', edge: 5.5 },
  { sport: 'CS2', player: 'm0NESY', prop: 'Most Headshots', type: 'Headshots', book: 'DraftKings', bookOdds: '+145', fairOdds: '+127', hitRate: '57%', edge: 7.1 },
  { sport: 'CS2', player: 'donk', prop: 'Map 1 Kills Over 21.5', type: 'Map 1 Kills', book: 'FanDuel', bookOdds: '+114', fairOdds: '+100', hitRate: '61%', edge: 6.2 },
  { sport: 'CS2', player: 'ropz', prop: 'Map 2 Kills Over 18.5', type: 'Map 2 Kills', book: 'BetMGM', bookOdds: '+125', fairOdds: '+109', hitRate: '60%', edge: 7.0 },
  { sport: 'CS2', player: 'ZywOo', prop: 'Maps 1–2 Kills Over 39.5', type: 'Maps 1-2 Kills', book: 'Pinnacle', bookOdds: '+120', fairOdds: '+104', hitRate: '63%', edge: 7.3 },
  { sport: 'CS2', player: 'broky', prop: 'First Kill Over 5.5', type: 'First Kills', book: 'Fanatics', bookOdds: '+136', fairOdds: '+118', hitRate: '55%', edge: 7.2 },
  { sport: 'CS2', player: 'device', prop: 'Over 10.5 Headshots', type: 'Headshots', book: 'PrizePicks', bookOdds: '+108', fairOdds: '-101', hitRate: '58%', edge: 4.9 },
  { sport: 'CS2', player: 's1mple', prop: 'Over 0.5 Aces', type: 'Aces', book: 'Kalshi', bookOdds: '+280', fairOdds: '+235', hitRate: '18%', edge: 8.7 },
  { sport: 'CS2', player: 'frozen', prop: 'Over 1.5 Clutches', type: 'Clutches', book: 'Polymarket', bookOdds: '+230', fairOdds: '+201', hitRate: '29%', edge: 6.4 }
];

const bestOddsData = [
  { title: 'NBA Best Prices', subtitle: 'More books across the board', lines: [
    ['Luka Over 8.5 AST', 'DraftKings +120'],
    ['Jokic Over 47.5 PRA', 'Caesars +118'],
    ['Edwards Over 5.5 AST', 'Fanatics +132'],
    ['Curry Over 29.5 Points', 'BetMGM +110']
  ]},
  { title: 'MLB Best Prices', subtitle: 'Baseball props and alt markets', lines: [
    ['Soto Over 1.5 TB', 'BetMGM +140'],
    ['Judge HR', 'ESPN BET +305'],
    ['Betts H+R+RBI', 'Underdog -105'],
    ['Witt Jr. SB', 'PrizePicks +210']
  ]},
  { title: 'CS2 Best Prices', subtitle: 'Kills, headshots, map props, and more', lines: [
    ['ZywOo Maps 1–2 Kills', 'Pinnacle +120'],
    ['m0NESY Most Headshots', 'DraftKings +145'],
    ['donk Map 1 Kills', 'FanDuel +114'],
    ['s1mple Aces', 'Kalshi +280'],
    ['frozen Clutches', 'Polymarket +230']
  ]},
  { title: 'Market Watch', subtitle: 'Prediction-market style boards', lines: [
    ['s1mple Aces Yes', 'Kalshi +280'],
    ['frozen 2+ Clutches', 'Polymarket +230'],
    ['donk 40+ Maps 1–2 Kills', 'Kalshi +210']
  ]}
];

const views = document.querySelectorAll('.view');
const navBtns = document.querySelectorAll('.nav-btn');
const scannerRows = document.getElementById('scannerRows');
const oddsCards = document.getElementById('oddsCards');
const summaryGrid = document.getElementById('summaryGrid');
const minEdge = document.getElementById('minEdge');
const minEdgeValue = document.getElementById('minEdgeValue');
const refreshBtn = document.getElementById('refreshBtn');
const sportFilters = document.querySelectorAll('.sport-filter');
const bookFiltersWrap = document.getElementById('bookFilters');
const propFiltersWrap = document.getElementById('propFilters');

const books = [...new Set(sampleBets.map(x => x.book))];
const propTypes = [...new Set(sampleBets.map(x => x.type))];

bookFiltersWrap.innerHTML = books.map((book, i) => `<label><input type="checkbox" class="book-filter" value="${book}" ${i < 8 ? 'checked' : ''}> ${book}</label>`).join('');
propFiltersWrap.innerHTML = propTypes.map((type, i) => `<label><input type="checkbox" class="prop-filter" value="${type}" ${i < 8 ? 'checked' : ''}> ${type}</label>`).join('');

function selectedValues(selector) {
  return [...document.querySelectorAll(selector)].filter(x => x.checked).map(x => x.value);
}

function renderSummary(bets) {
  const avgEdge = bets.length ? (bets.reduce((a,b) => a + b.edge, 0) / bets.length).toFixed(1) : '0.0';
  const topEdge = bets.length ? Math.max(...bets.map(b => b.edge)).toFixed(1) : '0.0';
  summaryGrid.innerHTML = `
    <div class="metric-card"><span>Qualified Bets</span><strong>${bets.length}</strong></div>
    <div class="metric-card"><span>Average Edge</span><strong>${avgEdge}%</strong></div>
    <div class="metric-card"><span>Top Edge</span><strong>${topEdge}%</strong></div>
    <div class="metric-card"><span>Books Live</span><strong>${new Set(bets.map(b => b.book)).size}</strong></div>
  `;
}

function renderScanner() {
  const selectedSports = selectedValues('.sport-filter');
  const selectedBooks = selectedValues('.book-filter');
  const selectedProps = selectedValues('.prop-filter');
  const threshold = parseFloat(minEdge.value);
  minEdgeValue.textContent = `${threshold.toFixed(1)}%`;

  const filtered = sampleBets
    .filter(b => selectedSports.includes(b.sport))
    .filter(b => selectedBooks.includes(b.book))
    .filter(b => selectedProps.includes(b.type))
    .filter(b => b.edge >= threshold)
    .sort((a, b) => b.edge - a.edge);

  renderSummary(filtered);
  scannerRows.innerHTML = filtered.map(row => `
    <tr>
      <td>${row.sport}</td>
      <td>${row.player}</td>
      <td>${row.prop}</td>
      <td>${row.type}</td>
      <td>${row.book}</td>
      <td>${row.bookOdds}</td>
      <td>${row.fairOdds}</td>
      <td class="edge">+${row.edge.toFixed(1)}%</td>
      <td>${row.hitRate}</td>
    </tr>
  `).join('') || `<tr><td colspan="9">No bets match the current filters.</td></tr>`;
}

function renderOdds() {
  oddsCards.innerHTML = bestOddsData.map(card => `
    <div class="odds-card">
      <h3>${card.title}</h3>
      <p>${card.subtitle}</p>
      ${card.lines.map(line => `<div class="odds-line"><span>${line[0]}</span><strong>${line[1]}</strong></div>`).join('')}
    </div>
  `).join('');
}

navBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    navBtns.forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    const viewName = btn.dataset.view;
    views.forEach(v => v.classList.toggle('active', v.id === viewName));
    document.getElementById('viewTitle').textContent = btn.textContent;
  });
});

function bindFilters() {
  [minEdge, ...document.querySelectorAll('.sport-filter'), ...document.querySelectorAll('.book-filter'), ...document.querySelectorAll('.prop-filter')]
    .forEach(el => el.addEventListener('input', renderScanner));
}

refreshBtn.addEventListener('click', renderScanner);
bindFilters();
renderScanner();
renderOdds();
