window.ATX_CONFIG = {
  oddsApiKey: '', // The Odds API key for NBA/MLB props and odds
  pandaScoreApiKey: '', // PandaScore key for CS2 matches/stats
  oddsSports: ['basketball_nba', 'baseball_mlb'],
  oddsRegions: 'us',
  oddsBooks: [
    'draftkings','fanduel','betmgm','caesars','bet365','espnbet','fanatics'
  ],
  // Common player-prop markets on supported books/sports. Check provider availability.
  oddsMarkets: [
    'player_points','player_rebounds','player_assists','player_threes',
    'player_hits','player_home_runs','player_rbis','batter_total_bases',
    'h2h','spreads','totals'
  ],
  kalshiBase: 'https://api.elections.kalshi.com/trade-api/v2',
  polymarketBase: 'https://gamma-api.polymarket.com',
  pandascoreBase: 'https://api.pandascore.co/csgo'
};
